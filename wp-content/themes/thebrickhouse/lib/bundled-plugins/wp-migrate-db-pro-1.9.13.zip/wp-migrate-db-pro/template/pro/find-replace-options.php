<div class="option-section find-replace-options" style="display:none;">
	<div class="header-expand-collapse find-replace-options-toggle clearfix" data-next=".table-options, .exclude-post-types-options, .advanced-options">
		<div class="expand-collapse-arrow">&#x25BC;</div>
		<div class="option-heading tables-header"><?php _e( 'Find & Replace Options', 'wp-migrate-db' ); ?></div>
	</div>
</div>